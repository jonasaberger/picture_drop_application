export interface FilterOptions {
  company?: string;
  workspace?: string;
  uploadType?: string;
  year?: string;
}
