export interface SubmissionItem {
  Id: number;
  SubmissionId: number;
  ContentType: string;
  CreatedOn: Date;
}
