import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BEFORE_APP_SERIALIZED,
  ENABLE_DOM_EMULATION,
  INITIAL_CONFIG,
  INTERNAL_SERVER_PLATFORM_PROVIDERS,
  PlatformState,
  SERVER_CONTEXT,
  SERVER_RENDER_PROVIDERS,
  ServerModule,
  VERSION,
  platformServer,
  provideServerRendering,
  renderApplication,
  renderInternal,
  renderModule
} from "./chunk-FBGSZEBJ.js";
import "./chunk-S3P4F377.js";
import "./chunk-O62YEPRP.js";
import "./chunk-S5AXQ3RQ.js";
import "./chunk-K6LG6YQ2.js";
import "./chunk-VESJBO63.js";
import "./chunk-GJNSHSL2.js";
import "./chunk-XOB36AR6.js";
import "./chunk-YHCV7DAQ.js";
export {
  BEFORE_APP_SERIALIZED,
  INITIAL_CONFIG,
  PlatformState,
  ServerModule,
  VERSION,
  platformServer,
  provideServerRendering,
  renderApplication,
  renderModule,
  ENABLE_DOM_EMULATION as ɵENABLE_DOM_EMULATION,
  INTERNAL_SERVER_PLATFORM_PROVIDERS as ɵINTERNAL_SERVER_PLATFORM_PROVIDERS,
  SERVER_CONTEXT as ɵSERVER_CONTEXT,
  SERVER_RENDER_PROVIDERS as ɵSERVER_RENDER_PROVIDERS,
  renderInternal as ɵrenderInternal
};
